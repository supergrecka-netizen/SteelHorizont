extends Node

var player_health := 100
var credits := 0
var experience := 0
var save_version := 1
