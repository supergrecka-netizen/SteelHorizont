extends Control
class_name BattleHUD

var move_axis := Vector2.ZERO
var aim_drag := Vector2.ZERO
var message_time := 0.0
var message_text := ""
var stick_touch := -1
var aim_touch := -1
var stick_origin := Vector2(110, 0)
var stick_current := Vector2.ZERO
var fire_rect := Rect2()
var stick_rect := Rect2()
var aim_rect := Rect2()

func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP

func _process(delta: float) -> void:
	message_time = maxf(0.0, message_time - delta)
	queue_redraw()

func _draw() -> void:
	var size := get_viewport_rect().size
	stick_origin = Vector2(112, size.y - 118)
	stick_rect = Rect2(Vector2(20, size.y - 220), Vector2(190, 200))
	fire_rect = Rect2(Vector2(size.x - 160, size.y - 175), Vector2(125, 125))
	aim_rect = Rect2(Vector2(size.x * 0.36, 0), Vector2(size.x * 0.42, size.y))
	draw_rect(Rect2(20, 20, 260, 66), Color(0.02, 0.04, 0.05, 0.62), true)
	draw_string(ThemeDB.fallback_font, Vector2(36, 46), "СТАЛЬНОЙ ГОРИЗОНТ", HORIZONTAL_ALIGNMENT_LEFT, -1, 17, Color.WHITE)
	draw_string(ThemeDB.fallback_font, Vector2(36, 70), "WASD / левый джойстик · SPACE / ОГОНЬ", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color(0.8, 0.88, 0.82))
	draw_circle(stick_origin, 66, Color(0.1, 0.13, 0.14, 0.38))
	draw_arc(stick_origin, 66, 0, TAU, 48, Color(0.8, 0.85, 0.8, 0.65), 2.0)
	draw_circle(stick_origin + move_axis * 42.0, 27, Color(0.65, 0.75, 0.67, 0.7))
	draw_circle(fire_rect.get_center(), 54, Color(0.72, 0.16, 0.08, 0.76))
	draw_arc(fire_rect.get_center(), 54, 0, TAU, 48, Color(1.0, 0.75, 0.5), 3.0)
	draw_string(ThemeDB.fallback_font, fire_rect.get_center() + Vector2(-27, 6), "ОГОНЬ", HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color.WHITE)
	draw_rect(Rect2(size.x - 285, 22, 260, 28), Color(0.05, 0.05, 0.05, 0.65), true)
	draw_rect(Rect2(size.x - 281, 26, 252 * (float(GameState.player_health) / 100.0), 20), Color(0.23, 0.72, 0.25, 0.95), true)
	draw_string(ThemeDB.fallback_font, Vector2(size.x - 280, 72), "ПРОТИВНИКИ: %d" % get_tree().get_nodes_in_group("enemies").size(), HORIZONTAL_ALIGNMENT_LEFT, -1, 16, Color.WHITE)
	if message_time > 0.0:
		draw_string(ThemeDB.fallback_font, Vector2(size.x * 0.5 - 80, 90), message_text, HORIZONTAL_ALIGNMENT_CENTER, 250, 20, Color(1.0, 0.86, 0.35))

func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			if stick_rect.has_point(event.position):
				stick_touch = event.index
				_update_stick(event.position)
			elif fire_rect.has_point(event.position):
				var player = get_tree().get_first_node_in_group("player")
				if player: player.fire()
			elif aim_rect.has_point(event.position):
				aim_touch = event.index
		else:
			if event.index == stick_touch:
				stick_touch = -1
				move_axis = Vector2.ZERO
			if event.index == aim_touch:
				aim_touch = -1
	elif event is InputEventScreenDrag:
		if event.index == stick_touch:
			_update_stick(event.position)
		elif event.index == aim_touch:
			aim_drag += event.relative

func _update_stick(pos: Vector2) -> void:
	move_axis = (pos - stick_origin).limit_length(62.0) / 62.0

func show_message(text_value: String) -> void:
	message_text = text_value
	message_time = 1.1
