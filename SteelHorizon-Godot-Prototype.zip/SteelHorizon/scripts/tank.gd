extends CharacterBody3D
class_name Tank

@export var is_player := false
@export var max_health := 100.0
@export var move_speed := 7.0
@export var reverse_speed := 3.0
@export var turn_speed := 1.15
@export var reload_seconds := 2.2
var health := 100.0
var reload_left := 0.0
var target: Node3D
var turret: Node3D
var barrel: Node3D
var health_label := ""
var ai_fire_timer := 1.0
var body_material: StandardMaterial3D

func _ready() -> void:
	health = max_health
	_build_model()
	if not is_player:
		add_to_group("enemies")

func _build_model() -> void:
	var hull := MeshInstance3D.new()
	var hull_mesh := BoxMesh.new()
	hull_mesh.size = Vector3(2.5, 0.8, 3.6)
	hull.mesh = hull_mesh
	body_material = StandardMaterial3D.new()
	body_material.albedo_color = Color(0.24, 0.29, 0.19) if is_player else Color(0.35, 0.18, 0.14)
	body_material.roughness = 0.92
	hull.material_override = body_material
	hull.position.y = 0.65
	add_child(hull)
	var shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(2.6, 1.2, 3.8)
	shape.shape = box
	shape.position.y = 0.65
	add_child(shape)
	for side in [-1.0, 1.0]:
		var track := MeshInstance3D.new()
		var tm := BoxMesh.new()
		tm.size = Vector3(0.42, 0.72, 3.8)
		track.mesh = tm
		track.position = Vector3(side * 1.42, 0.62, 0)
		var mat := StandardMaterial3D.new()
		mat.albedo_color = Color(0.12, 0.13, 0.12)
		track.material_override = mat
		add_child(track)
	var turret_mount := Node3D.new()
	turret_mount.name = "Turret"
	turret_mount.position = Vector3(0, 1.15, -0.15)
	add_child(turret_mount)
	turret = turret_mount
	var turret_mesh := MeshInstance3D.new()
	var tm2 := BoxMesh.new()
	tm2.size = Vector3(1.55, 0.58, 1.65)
	turret_mesh.mesh = tm2
	turret_mesh.material_override = body_material
	turret_mount.add_child(turret_mesh)
	barrel = Node3D.new()
	barrel.name = "Barrel"
	barrel.position = Vector3(0, 0.03, -0.95)
	turret_mount.add_child(barrel)
	var gun := MeshInstance3D.new()
	var gm := CylinderMesh.new()
	gm.top_radius = 0.095
	gm.bottom_radius = 0.12
	gm.height = 2.1
	gun.mesh = gm
	gun.rotation.x = PI / 2.0
	gun.position.z = -0.95
	gun.material_override = body_material
	barrel.add_child(gun)

func _physics_process(delta: float) -> void:
	reload_left = maxf(0.0, reload_left - delta)
	if is_player:
		_player_control(delta)
	else:
		_ai_control(delta)
	velocity.y -= 18.0 * delta
	move_and_slide()
	if global_position.y < -5.0:
		global_position.y = 1.0
		velocity = Vector3.ZERO

func _player_control(delta: float) -> void:
	var forward_input := Input.get_action_strength("move_forward") - Input.get_action_strength("move_back")
	var turn_input := Input.get_action_strength("turn_left") - Input.get_action_strength("turn_right")
	if has_node("../HUD"):
		var hud = get_node("../HUD")
		if absf(hud.move_axis.y) > 0.05:
			forward_input = hud.move_axis.y
		if absf(hud.move_axis.x) > 0.05:
			turn_input = -hud.move_axis.x
		if hud.aim_drag.length() > 0.01:
			turret.rotate_y(-hud.aim_drag.x * 0.004)
			barrel.rotation.x = clampf(barrel.rotation.x - hud.aim_drag.y * 0.002, -0.22, 0.28)
			hud.aim_drag = Vector2.ZERO
	rotation.y += turn_input * turn_speed * delta
	var speed := move_speed if forward_input >= 0 else reverse_speed
	var desired := -global_transform.basis.z * forward_input * speed
	velocity.x = move_toward(velocity.x, desired.x, 5.0 * delta)
	velocity.z = move_toward(velocity.z, desired.z, 5.0 * delta)
	if Input.is_action_just_pressed("fire"):
		fire()

func _ai_control(delta: float) -> void:
	if not is_instance_valid(target):
		var players := get_tree().get_nodes_in_group("player")
		if not players.is_empty(): target = players[0]
		return
	var to_target := target.global_position - global_position
	var distance := to_target.length()
	var desired_yaw := atan2(-to_target.x, -to_target.z)
	rotation.y = rotate_toward(rotation.y, desired_yaw, turn_speed * 0.55 * delta)
	var angle_diff := absf(wrapf(desired_yaw - rotation.y, -PI, PI))
	if distance > 12.0 and angle_diff < 0.8:
		var desired := -global_transform.basis.z * move_speed * 0.55
		velocity.x = move_toward(velocity.x, desired.x, 3.0 * delta)
		velocity.z = move_toward(velocity.z, desired.z, 3.0 * delta)
	else:
		velocity.x = move_toward(velocity.x, 0.0, 4.0 * delta)
		velocity.z = move_toward(velocity.z, 0.0, 4.0 * delta)
	var local_target := turret.to_local(target.global_position)
	turret.rotation.y = rotate_toward(turret.rotation.y, atan2(-local_target.x, -local_target.z), 1.1 * delta)
	ai_fire_timer -= delta
	if distance < 38.0 and ai_fire_timer <= 0.0:
		fire()
		ai_fire_timer = randf_range(2.0, 3.4)

func fire() -> void:
	if reload_left > 0.0 or health <= 0.0: return
	reload_left = reload_seconds
	var muzzle := barrel.global_position + (-barrel.global_transform.basis.z * 1.45)
	var direction := -barrel.global_transform.basis.z
	var projectile := Projectile.new()
	projectile.global_position = muzzle
	projectile.direction = direction.normalized()
	projectile.owner_tank = self
	get_tree().current_scene.add_child(projectile)
	if is_player and has_node("../HUD"):
		get_node("../HUD").show_message("ВЫСТРЕЛ")

func take_damage(amount: float, impact: Vector3) -> void:
	health = maxf(0.0, health - amount)
	if is_player:
		GameState.player_health = int(health)
	if health <= 0.0:
		if is_player:
			get_tree().call_deferred("reload_current_scene")
		else:
			queue_free()
