extends Area3D
class_name Projectile

var direction := Vector3.FORWARD
var owner_tank: Tank
var speed := 62.0
var life := 3.0
var damage := 42.0
var previous_position := Vector3.ZERO

func _ready() -> void:
	var mesh_instance := MeshInstance3D.new()
	var mesh := SphereMesh.new()
	mesh.radius = 0.13
	mesh.height = 0.26
	mesh_instance.mesh = mesh
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(1.0, 0.63, 0.18)
	mat.emission_enabled = true
	mat.emission = Color(1.0, 0.28, 0.04)
	mesh_instance.material_override = mat
	add_child(mesh_instance)
	var collision := CollisionShape3D.new()
	var sphere := SphereShape3D.new()
	sphere.radius = 0.18
	collision.shape = sphere
	add_child(collision)
	monitoring = false
	previous_position = global_position

func _physics_process(delta: float) -> void:
	life -= delta
	if life <= 0.0:
		queue_free()
		return
	var next_position := global_position + direction * speed * delta
	var query := PhysicsRayQueryParameters3D.create(global_position, next_position)
	query.exclude = [get_rid()]
	if is_instance_valid(owner_tank): query.exclude.append(owner_tank.get_rid())
	query.collide_with_areas = false
	var hit := get_world_3d().direct_space_state.intersect_ray(query)
	if not hit.is_empty():
		var collider = hit.get("collider")
		if collider is Tank and collider != owner_tank:
			var normal: Vector3 = hit.get("normal", Vector3.UP)
			var incidence := absf(direction.dot(normal))
			var actual_damage := damage if incidence > 0.28 else damage * 0.35
			collider.take_damage(actual_damage, hit.position)
			if is_instance_valid(owner_tank) and owner_tank.is_player:
				var hud = owner_tank.get_node_or_null("../HUD")
				if hud: hud.show_message("ПОПАДАНИЕ  -%.0f HP" % actual_damage)
		queue_free()
		return
	global_position = next_position
	previous_position = global_position
