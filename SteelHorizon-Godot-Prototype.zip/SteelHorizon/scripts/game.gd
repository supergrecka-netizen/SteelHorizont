extends Node3D

func _ready() -> void:
	GameState.player_health = 100
	_build_world()
	var player := _spawn_tank(Vector3(0, 0.1, 10), true)
	player.add_to_group("player")
	var camera := Camera3D.new()
	camera.name = "FollowCamera"
	camera.position = Vector3(0, 6.5, 10)
	camera.current = true
	player.add_child(camera)
	camera.rotation_degrees = Vector3(-18, 0, 0)
	var hud := BattleHUD.new()
	hud.name = "HUD"
	get_tree().current_scene.call_deferred("add_child", hud)
	for p in [Vector3(-12, 0.1, -12), Vector3(12, 0.1, -22), Vector3(0, 0.1, -32)]:
		var enemy := _spawn_tank(p, false)
		enemy.target = player
	var light := DirectionalLight3D.new()
	light.rotation_degrees = Vector3(-50, -25, 0)
	light.light_energy = 1.2
	add_child(light)
	var env := WorldEnvironment.new()
	var environment := Environment.new()
	environment.background_mode = Environment.BG_SKY
	environment.sky = Sky.new()
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color(0.55, 0.61, 0.66)
	environment.ambient_light_energy = 0.7
	env.environment = environment
	add_child(env)

func _build_world() -> void:
	var ground := StaticBody3D.new()
	ground.name = "Ground"
	var mesh_instance := MeshInstance3D.new()
	var plane := PlaneMesh.new()
	plane.size = Vector2(180, 180)
	mesh_instance.mesh = plane
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.34, 0.36, 0.27)
	mat.roughness = 1.0
	mesh_instance.material_override = mat
	ground.add_child(mesh_instance)
	var col := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(180, 1, 180)
	col.shape = box
	col.position.y = -0.5
	ground.add_child(col)
	add_child(ground)
	# Buildings and barriers use real static collision bodies.
	for i in range(14):
		var obstacle := StaticBody3D.new()
		var obstacle_mesh := MeshInstance3D.new()
		var bm := BoxMesh.new()
		var sx := randf_range(2.5, 6.0)
		var sz := randf_range(2.5, 6.0)
		var sy := randf_range(1.5, 5.0)
		bm.size = Vector3(sx, sy, sz)
		obstacle_mesh.mesh = bm
		var om := StandardMaterial3D.new()
		om.albedo_color = [Color(0.36, 0.35, 0.30), Color(0.27, 0.30, 0.28), Color(0.42, 0.39, 0.32)][i % 3]
		om.roughness = 1.0
		obstacle_mesh.material_override = om
		obstacle.add_child(obstacle_mesh)
		var obstacle_col := CollisionShape3D.new()
		var obstacle_shape := BoxShape3D.new()
		obstacle_shape.size = bm.size
		obstacle_col.shape = obstacle_shape
		obstacle.add_child(obstacle_col)
		obstacle.position = Vector3(randf_range(-28, 28), sy / 2.0, randf_range(-40, 20))
		add_child(obstacle)
	# Road strip.
	var road := MeshInstance3D.new()
	var road_mesh := BoxMesh.new()
	road_mesh.size = Vector3(7, 0.05, 110)
	road.mesh = road_mesh
	var road_mat := StandardMaterial3D.new()
	road_mat.albedo_color = Color(0.19, 0.20, 0.19)
	road.material_override = road_mat
	road.position = Vector3(0, 0.03, -15)
	add_child(road)

func _spawn_tank(pos: Vector3, player: bool) -> Tank:
	var tank := Tank.new()
	tank.is_player = player
	tank.position = pos
	add_child(tank)
	return tank
